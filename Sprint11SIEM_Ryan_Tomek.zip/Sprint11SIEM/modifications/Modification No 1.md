---
entity type:
  - modification
device:
  - Blue-Team Workstation
changelogs: ADD LINKS TO RELEVANT CHANGELOG ENTRIES
description: ADD DESCRIPTION HERE
---
# Overview
> [!tip]- Describe the modification in brief here.
> Be sure to include details like **what the modification is** and **why you want to make it**.



# TODO
> [!tip]- List the steps involved in implementing and testing this modification.
> Indent this checklist to keep tasks hierarchically organized. Try to break all the steps down into the smallest chunks possible so that it's easy to track and annotate your progress.

- [ ] ADD
- [ ] ITEMS
- [ ] HERE
	- [ ] Sub-task should be indented to keep things tidy


# References
> [!tip] List any external [[References]] you're using to figure out how to implement and test this modification.

- [ ] ADD
- [ ] REFERENCES
- [ ] HERE

# Involved devices
> [!tip]- List any [[Devices]] you will need to access while implementing this modification.
> Be clear what role each device you list plays in implementing this modification.

- #LINK-TO-RELEVANT-NOTES-HERE 
- 
# Involved files
> [!tip] List any [[files]] you will need to modify or create while implementing this modification.

- #LINK-TO-RELEVANT-NOTES-HERE 
- 

> [!success] Use the **Linked mentions** section below to discover all other entries that are somehow related to this modification.
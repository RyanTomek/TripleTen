---
entity type:
  - summary page
description: Home for all modifications made in this deployment.
aliases:
  - modification
---

> [!faq]- Want to add a new modifications entry?
> - `alt`/`option ⌥` + `N` to create a new note in this modifications folder.
> - `alt`/`option ⌥` + `T` to list available templates.
> - Choose the **[[Modifications template]]**.

You should have at least one environment modification in your [[Plan Proposal]].
- Once the [[Plan Proposal|plan]] is approved, use the [[Modification No 1]] entry to track your progress.
- Review the backlinks ("**Linked mentions**") on [[Modification No 1]] to identify all other entries related to this modification.


```dataviewjs
dv.table(
  ["Modification", "Description"],
  dv.pages()
    .where(p =>
      Array.isArray(p["entity type"]) &&
      p["entity type"].includes("modification") &&
      p.file.name !== "Modifications template"
    )
    .map(p => [
      p.file.link,
      p.description ?? ""
    ])
);
```
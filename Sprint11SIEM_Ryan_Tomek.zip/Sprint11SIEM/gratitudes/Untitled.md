---
entity type:
  - Gratitude
date: 2025-07-19T16-31-31
name: Ana, Richard, Mike, Ali
description: Gratitude List 
---

# Who I'm grateful for
I'm grateful for the Triple10 team, specifically Ana, Richard, Mike, & Ali.  I would have had more trouble completing the tasks at hand had I not had professional along the way helping me.  




# 🙏 Why I'm grateful for this
I'm grateful for the project & for Triple10 because I don't know how I would break into the tech world without it/them.  I've been wanting to pursue a career in cybersecurity for several years & I haven't found right way until now. 



# 🌱 How something they created helped me grow
I really appreciate this project because it's something I'll have for my professional portfolio.  This project is proof that I've gained real life skills that I can show to a potential employer.   


# 🧭 How I found this
I found out about Triple10 via an Instagram ad.  I was scrolling Instagram when the ad appeared & talked about how a person can work remote in tech & gain all the skills needed to do so from the Triple10 bootcamp.  One of the things that sold me most was the 1:1 mentorship & the job guarantee. 

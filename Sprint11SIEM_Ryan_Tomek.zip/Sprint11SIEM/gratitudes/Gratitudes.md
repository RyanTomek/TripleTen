---
entity type:
  - summary page
description: Home for all gratitudes experienced during this project.
aliases:
  - gratitude
---

Use this note to keep track of the people and things you're grateful for helping you in some way throughout this process. You'll need to thank at least two (2) researchers in your blog post's [[5. Final thoughts]], so try to come up with at least two gratitude entries by the end of this process.

> [!faq]- Thought of somebody or something to thank?
> - `alt`/`option ⌥` + `N` to create a new note in this gratitudes folder.
> - `alt`/`option ⌥` + `T` to list available templates.
> - Choose the **[[Gratitude template]]**.


The gratitudes you've created so far are listed below.

```dataviewjs
dv.table(
  ["Gratitude", "Name", "Description"],
  dv.pages()
    .where(p =>
      Array.isArray(p["entity type"]) &&
      p["entity type"].includes("gratitude") &&
      p.file.name !== "Gratitude template"
    )
    .map(p => [
      p.file.link,
      p.name ?? "",
      p.description ?? ""
    ])
);
```


> [!tip] Gratitude is the gift that keeps on giving
> Acknowledging who helped you is a standard way of showing respect in the cybersecurity community — and it’s a _great_ way to make new friends. Sometimes you’ll even find a new mentor by tipping your hat to the researchers whose work helped you! The more sincere and thoughtful your note of gratitude, the more likely you’ll make new friends in the industry through your post.
# 1.1 "Teaser" overview

I'm testing my cybersecurity skills in an effort to penetrate Google’s "Google-Gruyere" simulated environment. I will be analyzing & performing different attacks in order to practice my skills. I will be performing different attacks like, privilege escalation, a cross-site script, & cookie manipulation. I don't know how difficult it will be to penetrate their vulnerable webserver but I plan on finding out while giving it my best shot!

# 1.2 Introducing yourself to the cyber community

I'm Ryan & I've always had an interest in computers & how they work. I became more interested in cyber security through individuals I met via Social Media. My desire to protect myself & others via cybersecurity peaked last November when I was scammed for a large portion of my money through a cyber scam. I'm now working with the FBI to retrieve my funds. I'm also learning about processes which will keep myself & others safe while using the internet. In this blog I will be playing with a simulated environment, Googles Google-Gruyere. The plan is to exploit their vulnerable webserver & to see what holes it has. This is my first blog post & I hope you find it useful, informative & fun!

## Setup

A.) Kali machine/workstation.

B.) The Windows server will host the active directory.

C.) Our Ubuntu server which will host Google-Gruyere which is our vulnerable application.

# Experiment 1

# Plan

The goal of this experiment is to find a way to elevate privilege within Google-Gruyere.

# Execution

## Privilege Escalation

First I created a username & password for Google-Gruyere. I logged into my account from the localhost. Once I was on my profile, I clicked on the "edit profile" tab. Going through the website source-code, I found the option to become an Admin.

![[Screenshot 2025-07-16 203902 1.png]]

![[Screenshot 2025-07-16 204025 1.png]]

The path to my source-code is ```view-source:http://127.0.0.1:8008/661525542847859333112274099685468137840/editprofile.gtl```

From here I realized that I could escalate privileges by manipulating this URL:

```http://127.0.0.1:8008/661525542847859333112274099685468137840/editprofile.gtl```

At which point I removed the `editprofile.gtl` & added a bit of code to the end of the URL. The code I added was `saveprofile?action=update&is_admin=True`. So the entire URL now reads:

```127.0.0.1:8008/661525542847859333112274099685468137840/saveprofile?action=update&is_admin=True```

Once I logged out & logged back in, I had admin privileges. I had a new tab titled `manage this server`.

![[Pasted image 20250717212709.png]]

Prior to executing this code, I did not have the ability to "manage this server".

Thanks to the Google-Gruyere walk through & a YouTube video, I was able to successfully elevate site privilege. All in all I found this experiment to be fun & manageable as a beginner. I would definitely suggest playing around with Google-Gruyere for anyone new to cybersecurity & pentesting.

# Findings

![[Screenshot 2025-07-17 211448.png]]

As per the above screenshot, we can see that our privilege elevation attack was successfully logged. This is further proof that the attack was executed successfully.

# References

[Web Application Exploits and Defenses](https://google-gruyere.appspot.com/part3#3__elevation_of_privilege)

[Families Forever: Resources for Families Formed Through Adoption or Guardianship](https://www.youtube.com/watch?v=MyVhVQvybD0&list=PLKOjyDDgNbOI2OV_pRJDmonIy1UCryndG&index=3)

# Experiment 2

# Plan

The plan is to see if the Google-Gruyere site is susceptible to XSS attacks.

# Execution

## Stored XSS

For my second experiment I chose to execute a stored XSS attack. For this exploit to work, I needed to find somewhere where I could store data on the website. By searching around the website, I was able to find the "new snippet" section which is an area where I could input data into a comment box.

![[Screenshot 2025-07-16 202629 1.png]]

From there I went to create a snippet/comment. I then wrote out the JavaScript script of:

```<a onmouseover="alert(document.cookie)" href="#">read this too!</a>```

![[Screenshot 2025-07-17 081114.png]]

I found out about this resource on github which allowed me to experiment with how to execute the mouse over stored XSS exploit. The website resource link is: [PayloadsAllTheThings](https://github.com/swisskyrepo/PayloadsAllTheThings/tree/master/XSS%20Injection#xss-using-html5-tags). I also found a youtuber who had exploited Google-Gruyere using a mouse over exploit: [Stored XSS YouTube](https://www.youtube.com/watch?v=9UNVgsI8BBI&list=PLKOjyDDgNbOI2OV_pRJDmonIy1UCryndG&index=2). These resources helped me to better understand how to execute a stored XSS attack on Google-Gruyere. The attack works by storing a payload (malicious code) within the comments section. This attack is executed when someone hovers their cursor/mouse over the comment text. In my instance a "read this too!" snippet contained the code that triggered a pop-up.

![[Screenshot 2025-07-18 212251.png]]

This pop-up message will show the cookie of the user who triggered it. Thanks to the resources online & a tutor named Richard, I was able to complete my first XSS attack. I found this experiment to be fun & valuable. It was fairly easy to follow along without being overly complex & frustrating. I would definitely suggest trying to execute a stored XSS attack using Google-Gruyere if you are new to cybersecurity/pentesting.

# Findings

![[Screenshot 2025-07-17 214442.png]]

As shown in the image above, I was able to successfully create a new snippet in Google-Gruyere & have it show up in my site logs. The log shows proof that my mouse over XSS attack showing cookies was logged correctly.

# References

[PayloadsAllTheThings/XSS Injection at master · swisskyrepo/PayloadsAllTheThings · GitHub](https://github.com/swisskyrepo/PayloadsAllTheThings/tree/master/XSS%20Injection#xss-using-html5-tags)

[XSS](https://www.youtube.com/watch?v=9UNVgsI8BBI&list=PLKOjyDDgNbOI2OV_pRJDmonIy1UCryndG&index=2)

[Web Application Exploits and Defenses](https://google-gruyere.appspot.com/part2#2__stored_xss)

# Experiment 3

# Plan

The plan is to take the information I gained about the cookie from the previous XSS attack & to gain permanent access through the creation of a new Admin account via manipulating the cookie.

# Execution

## Cookie Manipulation

For my current experiment I decided to try a cookie manipulation attack. Servers are stateless in the sense that they don't remember who made a request. Cookies are designed to help servers remember some information about a session for future sessions.

Upon logging into Google-Gruyere I analyzed the cookie I exploited from my previous XSS attack.

![[Screenshot 2025-07-18 212251 1.png]]

Due to my previous mouse over attack, I was able to discover the cookie structure used by Google-Gruyere which, looks like this:

`GRUYERE=118889672|Ryan||author`

Based on the cookie information I gained from my previous exploit I was able to leverage hidden parameters to create a new admin account. Once I was logged into my profile, I was able to change part of the URL containing

`login?uid=yes&pw=yes` within

```http://127.0.0.1:8008/475068007785892711903537264277129189036/login?uid=yes&pw=yes```

to

```saveprofile?action=new&uid=admimistrator|admin|author&pw=secret```

So now my URL read:

```127.0.0.1:8008/475068007785892711903537264277129189036/saveprofile?action=new&uid=admimistrator|admin|author&pw=secret```

Upon hitting enter, I was able to see that I had successfully created a new admin account.

![[Screenshot 2025-07-18 144348.png]]

I was able to logout of my current session & log back in using the new credentials. This further proved I had successfully created a new admin profile named "Administrator".

![[Screenshot 2025-07-18 144520111.png]]

Performing this attack made me feel excited. I felt like I really breached the Google-Gruyere system & made it do what I wanted. I had fun executing this attack & I highly recommend practicing your cybersecurity & pentesting skills using Google-Gruyere.

# Findings

![[Screenshot 2025-07-18 144416111.png]]

The image of the site logs from within my Kali terminal prove that I successfully created an Admin account using a cookie.

# References

[Cookie manipulation - YouTube](https://www.youtube.com/watch?v=cFuJ03nbQi8&list=PLKOjyDDgNbOI2OV_pRJDmonIy1UCryndG&index=4)

[PayloadsAllTheThings/.github at master · swisskyrepo/PayloadsAllTheThings · GitHub](https://github.com/swisskyrepo/PayloadsAllTheThings/tree/master/.github)

[Web Application Exploits and Defenses](https://google-gruyere.appspot.com/part3#3__cookie_manipulation)

# Conclusion

# 4.1 Summary of experimental findings

Through the completion of these experiments, I found that Google-Gruyere simulated environment allowed me to adequately test different methods of attack against a vulnerable system. I found that I was able to escalate privileges, cross-site script, & manipulate cookies all in the Google-Gruyere simulated environment. I found & it to be fun & rather straight forward.

# 4.2 Advice on avoiding mistakes

My advice for anyone who wishes to play with Google-Gruyere is to choose from the list of available attacks provided on the Google-Gruyere website: [Web Application Exploits and Defenses](https://google-gruyere.appspot.com/). I would not suggest trying to test attack methods that are not listed on the Google-Gruyere website. I would suggest following the steps they give on the Google-Gruyere website. If you need more information on how to complete an attack, I suggest web articles, ChatGPT/Google Gemini, or YouTube. In my case, I found YouTube to be especially helpful. Ultimately, finding a walk through which suits your learning style is most important.

# Final Thoughts

# 5.1 The coolest thing I learned

Out of the 3 attacks I performed, my favorite was the stored XSS followed by the cookie manipulation. Writing JavaScript code that worked as it was supposed to was really cool & fun.

# 5.2 One piece of advice

My best piece of advice for anyone looking to play with Google-Gruyere is to choose from their given list of acceptable exploits. Not every attack will work smoothly but the attacks suggested on the Google-Gruyere page should.

# 5.3 My favorite resource

My favorite resource was definitely a YouTuber named Ken Ross. He made the Google-Gruyere walk through very easy to understand & replicate.

# 5.4 Thank you (gratitudes)!

Thank you Google for creating this simulated environment to practice with. I'd like to thank the YouTuber Ken Ross & I'd definitely like to give a big thank you to Triple10 & the tutors who helped me along the way!

# References

# 1.
[PayloadsAllTheThings/.github at master · swisskyrepo/PayloadsAllTheThings · GitHub](https://github.com/swisskyrepo/PayloadsAllTheThings/tree/master/.github)

# 2.
[Cookie manipulation - YouTube](https://www.youtube.com/watch?v=cFuJ03nbQi8&list=PLKOjyDDgNbOI2OV_pRJDmonIy1UCryndG&index=4)

# 3.
[Elevation of privilege - YouTube](https://www.youtube.com/watch?v=MyVhVQvybD0&list=PLKOjyDDgNbOI2OV_pRJDmonIy1UCryndG&index=3)

# 4.
[XSS - YouTube](https://www.youtube.com/watch?v=9UNVgsI8BBI&list=PLKOjyDDgNbOI2OV_pRJDmonIy1UCryndG&index=2)

# 5.
[Web Application Exploits and Defenses](https://google-gruyere.appspot.com/)
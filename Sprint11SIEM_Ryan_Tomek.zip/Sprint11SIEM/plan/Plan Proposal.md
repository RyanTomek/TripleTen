


> [!error] The template for drafting the Plan Proposal you will submit is located at [[Sprint 11] Plan Proposal {TEMPLATE}](https://docs.google.com/document/d/1YucMFQkxTsEOUkATCz_tSyeSLmLPpq3MiQVyEALLKRg/copy).
> After your **Plan Proposal** document has been approved by an expert reviewer, *then* you should paste the relevant content into this document. After that, you can use this to fill out the [[Modifications]] and [[Experiments]] notes. Then add the TODOs from those notes into the [[The Plan]] document.

---
# Modifications to environment
### Modification #1
**Install Google Gruyere on Blue Team workstation to exploit common web security flaws.**

#### References to use while implementing
- [ ] **[https://google-gruyere.appspot.com/part1](https://google-gruyere.appspot.com/part1)**

---
---
---

# Experiments to run
### Experiment #1 Privilege Escalation 
The plan is to try to escalate privilege within Google-Gruyere.


#### References to use while conducting
- [ ] [Elevation of privilege - YouTube](https://www.youtube.com/watch?v=MyVhVQvybD0&list=PLKOjyDDgNbOI2OV_pRJDmonIy1UCryndG&index=6)
- [ ] [PayloadsAllTheThings/.github at master · swisskyrepo/PayloadsAllTheThings · GitHub](https://github.com/swisskyrepo/PayloadsAllTheThings/tree/master/.github)
- [ ] [Web Application Exploits and Defenses](https://google-gruyere.appspot.com/part3#3__elevation_of_privilege)

---
### Experiment #2 Stored XSS
For my second experiment I plan to perform a stored XSS attack within Google-Gruyere. 

#### References to use while conducting
- [ ] [XSS - YouTube](https://www.youtube.com/watch?v=9UNVgsI8BBI&list=PLKOjyDDgNbOI2OV_pRJDmonIy1UCryndG&index=2)
- [ ] [Web Application Exploits and Defenses](https://google-gruyere.appspot.com/part2#2__stored_xss)
- [ ] [PayloadsAllTheThings/.github at master · swisskyrepo/PayloadsAllTheThings · GitHub](https://github.com/swisskyrepo/PayloadsAllTheThings/tree/master/.github)

---
### Experiment #3 Cookie Manipulation
The plan for experiment 3 is to take the cookie from the previous experiment & use it to create a new admin account. 

#### References to use while conducting
- [ ] [Cookie manipulation - YouTube](https://www.youtube.com/watch?v=cFuJ03nbQi8&list=PLKOjyDDgNbOI2OV_pRJDmonIy1UCryndG&index=4)
- [ ] [PayloadsAllTheThings/.github at master · swisskyrepo/PayloadsAllTheThings · GitHub](https://github.com/swisskyrepo/PayloadsAllTheThings/tree/master/.github)
- [ ] [Web Application Exploits and Defenses](https://google-gruyere.appspot.com/part3#3__cookie_manipulation)


# Plan

The plan is to take the information I gained about the cookie from the previous XSS attack & to gain permanent access through the creation of a new Admin account via manipulating the cookie.   

# Execution
## Cookie Manipulation
For my current experiment I decided to try a cookie manipulation attack.  Servers are stateless in the sense that they don't remember who makes a request.  Cookies are designed to help servers remember some information about a session for future sessions.

Upon logging into Google-Gruyere I analyzed the cookie I exploited from my pervious XSS attack.  

![[Screenshot 2025-07-18 212251 1.png]]

Due to my previous mouse over attack, I was able to discover the cookie structure used by Google-Gruyere which, looks like this:  

`GRUYERE=118889672|Ryan||author`

Based on the cookie information I gained from my previous exploit I was able to leverage hidden parameters to create a new admin account.  Once I was logged into my profile, I was able to change part of the URL containing

`login?uid=yes&pw=yes` within 

```http://127.0.0.1:8008/475068007785892711903537264277129189036/login?uid=yes&pw=yes```

to

```saveprofile?action=new&uid=admimistrator|admin|author&pw=secret```

So now my URL read:

```127.0.0.1:8008/475068007785892711903537264277129189036/saveprofile?action=new&uid=admimistrator|admin|author&pw=secret```

Upon hitting enter, I was able to see that I had successfully created a new admin account.  

![[Screenshot 2025-07-18 144348.png]]

I was able to logout of my current session & log back in using the new credentials.  This further proved I had successfully created a new admin profile named "Administrator". 

![[Screenshot 2025-07-18 144520111.png]]

Performing this attack made me feel excited.  I felt like I really breached the Google-Gruyere system & made it do what I wanted.  I had fun executing this attack & I highly recommend practicing your cybersecurity & pentesting skills using Google-Gruyere.  


> 

# Findings
![[Screenshot 2025-07-18 144416111.png]]

 The image of the site logs from within my Kali terminal prove that I successfully created an Admin account using a cookie. 


# References
[Cookie manipulation - YouTube](https://www.youtube.com/watch?v=cFuJ03nbQi8&list=PLKOjyDDgNbOI2OV_pRJDmonIy1UCryndG&index=4)

[PayloadsAllTheThings/.github at master · swisskyrepo/PayloadsAllTheThings · GitHub](https://github.com/swisskyrepo/PayloadsAllTheThings/tree/master/.github)


> [!success] Use the **Linked mentions** section below to discover all other entries that are somehow related to this experiment.
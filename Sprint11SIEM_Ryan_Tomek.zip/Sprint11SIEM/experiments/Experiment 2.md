

# Plan

 The plan is to see if the Google-Gruyere site is susceptible to XSS attacks.
 

# Execution 
## Stored XSS

For my second experiment I choose to execute a stored XSS attack.  For this exploit to work, I needed to find somewhere where I could store data on the website.  By searching around the website, I was able to find the "new snippet" section which, is an area where I could input data into a comment box.

![[Screenshot 2025-07-16 202629 1.png]]

From there I went to create a snippet/comment.  I then wrote out the JavaScript script of: 

```<a onmouseover="alert(document.cookie)" href="#">read this too!</a>```

![[Screenshot 2025-07-17 081114.png]]

I found out about this resource on github which allowed me to experiment with how to execute the mouse over stored XSS exploit.  The website resource link is: [PayloadsAllTheThings](https://github.com/swisskyrepo/PayloadsAllTheThings/tree/master/XSS%20Injection#xss-using-html5-tags).  I also found a youtuber who had exploited Google-Gruyere using a mouse over exploit: [Stored XSS YouTube](https://www.youtube.com/watch?v=9UNVgsI8BBI&list=PLKOjyDDgNbOI2OV_pRJDmonIy1UCryndG&index=2).  These resources helped me to better understand how to execute a stored XSS attack on Google-Gruyere.  The attack works by storing a payload (malicious code) within the comments section.  This attack is executed when someone hovers their cursor/mouse over the comment text.  In my instance a "read this too!" snippet contained the code which triggered a pop-up.

![[Screenshot 2025-07-18 212251.png]]

This pop-up message will show the cookie of the user who triggers it.  Thanks to the resources online & a tutor named Richard, I was able to complete my first XSS attack.  I found this experiment to be fun & valuable.  It was fairly easy to follow along without being overly complex & frustrating.  I definitely suggest trying to execute a stored XSS attack using Google-Gruyere if you are new to cybersecurity/pentesting. 



# Findings

![[Screenshot 2025-07-17 214442.png]]

As shown in the image above, I was able to successfully create a new snippet in Google-Gruyere & have it show up in my site logs.  The log shows proof that my mouse over XSS attack showing cookies was logged correctly. 


# References
[PayloadsAllTheThings/XSS Injection at master · swisskyrepo/PayloadsAllTheThings · GitHub](https://github.com/swisskyrepo/PayloadsAllTheThings/tree/master/XSS%20Injection#xss-using-html5-tags)

[XSS](https://www.youtube.com/watch?v=9UNVgsI8BBI&list=PLKOjyDDgNbOI2OV_pRJDmonIy1UCryndG&index=2)

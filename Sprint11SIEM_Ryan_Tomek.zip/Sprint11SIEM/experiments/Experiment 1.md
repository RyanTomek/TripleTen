

# Plan

The goal of this experiment is to find a way to elevate privilege within Google-Gruyere.

# Execution

## Privilege Escalation 
First I created a username & password for Google-Gruyere.  I logged into my account from the localhost.  Once I was in my profile, I clicked on the "edit profile" tab.  Going through the website source-code, I found the option to become an Admin.

![[Screenshot 2025-07-16 203902 1.png]]
![[Screenshot 2025-07-16 204025 1.png]]

The path to the my source-code is ```view-source:http://127.0.0.1:8008/661525542847859333112274099685468137840/editprofile.gtl``` 

From here I realized that I could escalate privilege by manipulating this URL: 

```http://127.0.0.1:8008/661525542847859333112274099685468137840/editprofile.gtl```

At which point I removed the `editprofile.gtl` & added a bit of code to the end of the URL.  The code I added was `saveprofile?action=update&is_admin=True`.  So the entire URL now read:

```127.0.0.1:8008/661525542847859333112274099685468137840/saveprofile?action=update&is_admin=True```

Once I logged out & logged back in, I had admin privilege.  I had a new tab titled `manage this server`.

![[Pasted image 20250717212709.png]]

Prior to executing this code, I did not have the ability to "manage this server".

Thanks to the Google-Gruyere walk through & a YouTube video, I was able to successfully elevate site privilege.  All in all I found this experiment to be fun & manageable as a beginner.  I would definitely suggest playing around with Google-Gruyere for anyone new to cybersecurity & pentesting. 


# Findings

![[Screenshot 2025-07-17 211448.png]]

As per the above screenshot, we find that our privilege elevation attack was successfully logged.  This is further proof that the attack was executed successfully.  


# References
[Web Application Exploits and Defenses](https://google-gruyere.appspot.com/part3#3__elevation_of_privilege)

[Families Forever: Resources for Families Formed Through Adoption or Guardianship](https://www.youtube.com/watch?v=MyVhVQvybD0&list=PLKOjyDDgNbOI2OV_pRJDmonIy1UCryndG&index=3) 


> [!success] Use the **Linked mentions** section below to discover all other entries that are somehow related to this experiment.
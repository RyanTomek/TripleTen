---
entity type:
  - file
name: sysmonconfig-export.xml
description: Starter config for Sysmon on Windows (Neo23x0's)
device:
  - ad01
URL: https://github.com/Neo23x0/sysmon-config/blob/master/sysmonconfig-export.xml
filepath:
---
Configuration file for [[Sysmon (Windows)]].

# Deployed on...
- [[observer]]

# File contents
See attached file: ![[sysmonconfig-export.xml]]

```xml
(paste file contents here if not too long; if too long, then drag & drop file to attach it to your notebook)
```


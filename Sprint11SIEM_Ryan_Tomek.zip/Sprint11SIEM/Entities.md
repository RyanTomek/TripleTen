---
aliases:
  - entity
---

This Obsidian notebook comes pre-loaded with some useful **entities** designed to make it easier for you to take good notes. 
- Each entity has its own associated [[Templates|template]].
- Each entity's summary "home" page displays an up-to-date table of all currently-existing Obsidian notes belonging to that entity. *These tables are powered by the `entity type` field appearing in the frontmatter of each note belonging to that entity.*
- See each individual entity's home page to see a fleshed-out description of that entity.

> [!tip]
> An **entity** is a specific class of items in your database that all share certain characteristics (illustrated by the differences in the different [[Templates]] that exist). You can make up your own entities, too! The sky is the limit. We've just provided these as your "starter set" for learning how to organize your notes in this powerful way.

# Plan entities
These entities are used to keep track of relevant materials related to your [[The Plan]].
- **[[Modifications]]**
- **[[Experiments]]**

# Process notes entities
These entities are used to keep notes about [[Changelog|what you're doing]], external [[References|references]] you're using, alongside tracking your [[Mistakes|mistakes]] and [[Gratitudes|gratitudes]].
- **[[Changelog]]**
- **[[References]]**
- **[[Mistakes]]**
- **[[Gratitudes]]**

# Environment entities
These entities are used to keep track of technical details associated with your project.
- **[[Devices]]**
- **[[Datasources]]** 
- **[[Files]]**

# Blog-related entities
There are single templates associated with crafting your [[blog]] post, so there aren't specific "entity" pages or templates for these. 
- *Access the **[[Blog]]** page to see these single-use templates.*

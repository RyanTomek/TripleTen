---
entity type:
  - reference
title: Atomic Red Team GitHub
URL: https://github.com/redcanaryco/atomic-red-team
published date: 
author: 
author affiliation: 
description: GH repo for all the atomic tests
blog blurb: 
reference type:
  - website
date added: 
---

# Overview
> [!tip] Describe this resource in brief.
> What do you want to remember about why you saved this resource? Record it here.

This GitHub repo contains lots of information about all the different atomic tests available from Atomic Red Team.


# How did you find this?
> [!tip] Record briefly where you ran into this resource. 
> Was it a Google search, a link on another post, social media...? Keep track of where you found this so you can tell the story accurately.

Linked to throughout TripleTen's courseware.


# Related pages
> [!tip] Link any related notes in this Obsidian notebook to this reference.
> You can also link directly to this note within any other note in the vault. This'll help create backlinks to make it easier to track down where you used this reference during your process.

- #LINK-TO-RELEVANT-NOTES-HERE 


# Questions
> [!tip] Sometimes external resources make you ask questions about the material — like "What does this term mean?" or "Why wouldn't people just...?". 
> Use this section to keep track of any questions this resource inspired you to ask. These can be great to track, *especially* if you don't have the time right now to answer those questions!

- #ADD-YOUR-OWN-ANSWER-HERE 


# Notes
> [!tip] Any miscellaneous notes you want to keep about this resource can go into this section.

#ADD-YOUR-OWN-ANSWER-HERE 
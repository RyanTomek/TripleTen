---
entity type:
  - file
name: ENTER FILENAME HERE
description: ENTER DESCRIPTION HERE
device:
URL:
filepath:
---
Configuration file for ==(add link to related [[Datasource]], [[Changelog]], or [[Modifications]])==.

# Deployed on...
- LIST DEVICES THIS FILE IS DEPLOYED ON HERE

# File contents
See attached file: 

```
(paste file contents here if not too long; if too long, then drag & drop file to attach it to your notebook)
```


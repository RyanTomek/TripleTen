This is your Obsidian vault for keeping notes while deploying a SIEM.

> [!tip] Use the [[TODO List]] to track your progress towards completing this project.

You will use these notes later to craft a blog post describing this experience.
- You've been provided with [[Templates|templates]] to create new entries for populating all the different [[entities]] in this Obsidian notebook.
- Use the [[Changelog]] to keep track of your process as you go.
- See the [[Blog]] note for information about the blog post you will be writing to document your process.

```dataviewjs
dv.table(
  ["Homepage", "Description"],
  dv.pages()
    .where(p => p["entity type"] && p["entity type"].includes("summary page"))
    .map(p => [
      p.file.link,
      p.description ?? ""
    ])
);
```

> [!success] Done implementing your [[modifications]] and conducting your [[experiments]]? 
> You're now ready to write your blog post! 🎉 See the [[Blog]] note for details on how to do this with all the notes you've taken so far.

> [!faq] Never used Obsidian before? 
> See the Obsidian starter guide ([Glossary](https://help.obsidian.md/glossary)) and the [Basic formatting syntax](https://help.obsidian.md/syntax) reference sheet. Obsidian's help documentation is simple and straightforward — so it's worth reading through relevant sections as needed during your journey. *This won't be the last time you use this powerful note-taking tool!*

*This is version `1.0` of the `Sprint11SIEM` notebook for use in TripleTen's Cyber Security Analyst bootcamp.*
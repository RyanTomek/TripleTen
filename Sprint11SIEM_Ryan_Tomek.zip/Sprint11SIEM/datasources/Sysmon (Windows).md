---
entity type:
  - datasource
source name: Sysmon
device:
  - ad01
status:
  - deployed
  - tested
OSes:
  - Windows
description: Standard app for host event tracing
source category:
  - host
---

# References
- 

# Configuration file(s)
- 

# References
- 

# Configuration file(s)
- [[File - Sysmon - Windows - sysmonconfig-export.xml]]
- 
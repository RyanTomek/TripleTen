---
entity type:
  - datasource
source name: Sysmon
device:
  - observer
status:
  - deployed
  - tested
OSes:
  - Linux
description: Standard app for host event tracing
source category:
  - host
---

# References
- 

# Configuration file(s)
- (need to research one)
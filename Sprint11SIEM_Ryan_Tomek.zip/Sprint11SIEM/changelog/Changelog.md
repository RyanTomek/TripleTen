---
entity type:
  - summary page
description: Home for all the changelogs.
aliases:
  - changelogs
---

> [!faq]- Want to add a new changelog entry?
> - `alt`/`option ⌥` + `N` to create a new note in this changelog folder.
> - `alt`/`option ⌥` + `T` to list available templates.
> - Choose the **[[Changelog template]]**.

You can easily access all your existing changelog entries here:
```dataviewjs
function formatDate(dateStr) {
  const d = new Date(dateStr);
  if (isNaN(d)) return "";
  const pad = (n) => n.toString().padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} @ ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

function wrapText(content, maxWidthPx) {
  const text = Array.isArray(content) ? content.join(", ") : (content ?? "");
  return `<div style="max-width: ${maxWidthPx}px; word-wrap: break-word; white-space: normal;">${text}</div>`;
}

function wrapLink(linkObj, maxWidthPx) {
  return linkObj
    ? `<span style="max-width: ${maxWidthPx}px; display: inline-block; word-wrap: break-word; white-space: normal;">${linkObj}</span>`
    : "";
}

dv.table(
  ["Change", "Date", "Type", "Device", "Description"],
  dv.pages()
    .where(p => p["entity type"] && p["entity type"].includes("changelog"))
    .sort(p => p.date, "asc")
    .map(p => [
      wrapLink(p.file.link, 150),             // Note
      p.date ? wrapText(formatDate(p.date), 100) : "", // Date (wrapped)
      wrapText(p["change type"], 215),        // Type
      wrapText(p.device, 150),                // Device
      p.description ?? ""                     // Description
    ])
);
```

> [!tip] When you've completed your project, you'll need to decide which changelog entries are critical to reference while telling the story of your blog post. *View all [[Chosen Changelogs]].*